# Leonida Explorer — source-linked research update (2026-11-23)

Upload index.html into https://github.com/achristian74/leonida-explorer
using Add file > Upload files, replacing the existing root index.html.
Commit directly to main; GitHub Pages will republish at:
https://achristian74.github.io/leonida-explorer/

NEW
* 41 guide-listed finds: 10 meditation spots, 11 meteorite locations,
  15 standout vehicles, and 5 tree effigies.
* Search and filter public source markers separately from research shortlist.
* Pin shortcuts only if one corresponding marker name uniquely matches.
  Exact map coordinates come from Open GTA 6 Map, not from the research guides.
* Screenshot evidence filter. A screenshot does not automatically prove coordinates.
* Found checkboxes for all guide entries, even when no source pin can be matched.
* Source guide links on each checklist item and matched pin details.
* Fixed public category metadata parsing and pinnable item counts.
* Existing browser progress stays saved under the original localStorage key.

Accuracy: Curated guide listings are not equivalent to our own gameplay verification.
For unmatched guide entries, no coordinates have been guessed or invented.

SOURCES
https://github.com/fbritoferreira/gta6 (map and data CC BY 4.0)
https://creativecommons.org/licenses/by/4.0/
https://game-checklists.com/gta6/meditation-spots-checklist/
https://game-checklists.com/gta6/meteorites-checklist/
https://game-checklists.com/gta6/standout-vehicles-checklist/
https://gta6playertools.com/locations/tree-effigies

Your checkmarks are stored on-device, not in GitHub or on our server.
Backup regularly with the Backup button in the tracker.
